﻿namespace Game_World
{
    public enum ItemRarity
    {
        Common,
        Magical,
        Rare,
        Legendary
    }


    public enum WeaponTypeEnum
    {
        Melee,
        Ranged
    }
}
